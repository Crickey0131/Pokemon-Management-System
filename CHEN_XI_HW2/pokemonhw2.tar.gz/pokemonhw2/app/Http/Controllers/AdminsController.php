<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\User;
use App\Pokemon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
class AdminsController extends Controller
{
    public function index()
    {
	$pokemons = Pokemon::all();
	return view('admins.index',compact('pokemons'));
    }

    public function edit(Request $input){
	
	$pokes = Pokemon::all();
	foreach($pokes as $item) {
	    if($item->name == $input['name']) {
		//return "Already Exists!";
		return;
	    }
	}

	DB::table('pokemons')->insert([['name' => $input['name'], 'num' => 0]]);
	//return "Congratulations!!";
	header("Refresh:0");
    }

    static public function sum(){
	$pokes = Pokemon::all();
	$sum = 0;
	foreach($pokes as $item) {
	    $sum += $item->num;
	}
	return $sum;
    }
}
