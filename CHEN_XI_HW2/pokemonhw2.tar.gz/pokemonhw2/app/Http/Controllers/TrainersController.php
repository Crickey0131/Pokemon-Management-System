<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Pokemon;
class TrainersController extends Controller
{
    //
	public function index($id){
		$pokemon_name = Pokemon::find($id);
		return view('trainers.index',compact('pokemon_name'));
	}
}
