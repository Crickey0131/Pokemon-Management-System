<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Pokemon;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
class ProfilesController extends Controller
{
	public function index()
	{
		$loginer = Auth::user();
		$users = User::all();
		$pokemons = Pokemon::all();
		return view('profiles.index',compact('loginer','users','pokemons'));
	}


	public function edit(Request $nm){
		$auther = Auth::user();
		DB::table('users')->where('id',$auther->id)->update(['name'=> $nm['myname']]);
		DB::table('users')->where('id',$auther->id)->update(['email'=> $nm['myemail']]);
		DB::table('users')->where('id',$auther->id)->update(['hometown'=> $nm['myhometown']]);

		if($auther->pokemon_id != NULL) {
			DB::table('pokemons')->where('id',$auther->pokemon_id)->decrement('num');
		}

		DB::table('users')->where('id',$auther->id)->update(['pokemon_id'=> $nm['mypokemon']]);
		DB::table('pokemons')->where('id',$nm['mypokemon'])->increment('num');
		header("Refresh:0");
		//return "Congratulations!";
	}
}
