<!DOCTYPE html>
<html>
    <head>
	<title>Laravel</title>
    </head>
    <body>
	<div class="container">
	    <div class="content">
		<h2>{{$pokemon_name->name}} has been in {{$pokemon_name->trainers->count()}} trainers</h2>
		<ul>@foreach($pokemon_name->trainers as $trainer)
			<li><a href="">{{$trainer->name}}</a></li>
		@endforeach
		</ul>
	    </div>
	</div>
    </body>
</html>
