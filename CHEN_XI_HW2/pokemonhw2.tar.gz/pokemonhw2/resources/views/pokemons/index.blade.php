<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <h2>A List of Pokemons</h2>

                        <ul>
                                @foreach($pokemons as $pokemon)
                                        <li>
{{link_to_route('pokemons.trainers.index',$pokemon->name,[$pokemon->id])}}
					</li>
                                @endforeach
                        </ul>

            </div>
        </div>
    </body>
</html>
