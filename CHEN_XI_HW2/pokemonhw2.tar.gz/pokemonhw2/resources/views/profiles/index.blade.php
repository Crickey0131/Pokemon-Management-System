<!DOCTYPE html>
<?php
use App\Http\Controllers\ProfilesController;
?>
<html>
    <head>
	<title>Laravel</title>
    </head>
    <body>
	<div class="container">
	
	    <form class="form-horizontal" role="form" method="POST">
		{{ csrf_field() }}
		Email: <input type = "text" name = "myemail" value = "{{$loginer->email}}"><p>
		Name: <input type = "text" name = "myname" value = "{{$loginer->name}}"><p>
		Hometown: <input type = "text" name = "myhometown" value = "{{$loginer->hometown}}"><p>
		Pokemon: <select name = "mypokemon">
			@foreach($pokemons as $pokemon)
				@if ($loginer->pokemon && $loginer->pokemon->id === $pokemon->id)
				<option value = "{{$pokemon->id}}" selected>{{$pokemon->name}}</option>
				@else 
				<option value = "{{$pokemon->id}}">{{$pokemon->name}}</option>
				@endif
			@endforeach
			</select><p>
		<input type="submit" value="Submit">
	    </form>
		
	    <a href="/pokemonhw2/public/home">back</p>

	</div>
    </body>
</html>
