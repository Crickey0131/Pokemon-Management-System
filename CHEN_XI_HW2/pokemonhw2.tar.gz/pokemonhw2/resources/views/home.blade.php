@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
		<p>
		@if ($loginer->isAdmin)
			{{link_to_route('admins.index',"Admin Page",[$loginer->id])}}
		@endif
		</p>	
		<table border = "2">
			<tr><td>Name</td><td>Hometown</td><td>Pokemon</td><td>Action</td><td>Admin</td>
			@foreach($users as $user)
			<tr><td>{{$user->name}}</td>
			<td>{{$user->hometown}}</td>
			<td>
			@if ($user->pokemon)
			{{$user->pokemon->name}}
			@endif
			</td>
			<td>
				@if ($user->id === $loginer->id)
					{{link_to_route('profiles.index',"edit",[$loginer->id])}}
				@endif
			</td>

			<td>
				@if ($user->isAdmin) 
					{{"Yes"}}
				@else
					{{"No"}}
				@endif	
			</td>
			@endforeach
		</table>


	    </div>
        </div>
    </div>
</div>
@endsection
