<!DOCTYPE html>
<?php
use App\Http\Controllers\AdminsController;
?>
<html>
    <head>
	<title>Laravel</title>
    </head>
    <body>
	<div class="container">
	    <div class="content">
		<h2>There are {{AdminsController::sum()}} Pokemon in the system.</h2>
		<ul>@foreach($pokemons as $pokemon)
			<li>{{$pokemon->num}} {{$pokemon->name}}</li>
		@endforeach
	    </div>

	    <form class="form-horizontal" role="form" method="POST">
		{{ csrf_field() }}
		Pokemon: <input type = "text" name = "name"><p>

		<input type="submit" value="Add Pokemon">
	    </form>
	    <a href="/pokemonhw2/public/home">back</a>
	</div>
    </body>
</html>
