<!DOCTYPE html>
<?php
use App\Http\Controllers\ProfilesController;
?>
<html>
    <head>
	<title>Laravel</title>
    </head>
    <body>
	<div class="container">
	
	    <form class="form-horizontal" role="form" method="POST">
		<?php echo e(csrf_field()); ?>

		Email: <input type = "text" name = "myemail" value = "<?php echo e($loginer->email); ?>"><p>
		Name: <input type = "text" name = "myname" value = "<?php echo e($loginer->name); ?>"><p>
		Hometown: <input type = "text" name = "myhometown" value = "<?php echo e($loginer->hometown); ?>"><p>
		Pokemon: <select name = "mypokemon">
			<?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<?php if($loginer->pokemon && $loginer->pokemon->id === $pokemon->id): ?>
				<option value = "<?php echo e($pokemon->id); ?>" selected><?php echo e($pokemon->name); ?></option>
				<?php else: ?> 
				<option value = "<?php echo e($pokemon->id); ?>"><?php echo e($pokemon->name); ?></option>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</select><p>
		<input type="submit" value="Submit">
	    </form>
		
	    <a href="/pokemonhw2/public/home">back</p>

	</div>
    </body>
</html>
