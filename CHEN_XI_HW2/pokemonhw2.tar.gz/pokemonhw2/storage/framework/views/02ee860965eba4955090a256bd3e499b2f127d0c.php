<!DOCTYPE html>
<?php
use App\Http\Controllers\AdminsController;
?>
<html>
    <head>
	<title>Laravel</title>
    </head>
    <body>
	<div class="container">
	    <div class="content">
		<h2>There are <?php echo e(AdminsController::sum()); ?> Pokemon in the system.</h2>
		<ul><?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<li><?php echo e($pokemon->num); ?> <?php echo e($pokemon->name); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	    </div>

	    <form class="form-horizontal" role="form" method="POST">
		<?php echo e(csrf_field()); ?>

		Pokemon: <input type = "text" name = "name"><p>

		<input type="submit" value="Add Pokemon">
	    </form>
	    <a href="/pokemonhw2/public/home">back</a>
	</div>
    </body>
</html>
