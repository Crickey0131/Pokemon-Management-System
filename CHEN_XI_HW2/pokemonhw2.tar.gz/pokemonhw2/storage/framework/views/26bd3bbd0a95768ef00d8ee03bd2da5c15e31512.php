<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <h2>A List of Pokemons</h2>

                        <ul>
                                <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <li>
<?php echo e(link_to_route('pokemons.trainers.index',$pokemon->name,[$pokemon->id])); ?>

					</li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </ul>

            </div>
        </div>
    </body>
</html>
