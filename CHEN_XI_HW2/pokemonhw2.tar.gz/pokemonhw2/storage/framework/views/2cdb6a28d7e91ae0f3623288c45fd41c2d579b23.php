<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
		<p>
		<?php if($loginer->isAdmin): ?>
			<?php echo e(link_to_route('admins.index',"Admin Page",[$loginer->id])); ?>

		<?php endif; ?>
		</p>	
		<table border = "2">
			<tr><td>Name</td><td>Hometown</td><td>Pokemon</td><td>Action</td><td>Admin</td>
			<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<tr><td><?php echo e($user->name); ?></td>
			<td><?php echo e($user->hometown); ?></td>
			<td>
			<?php if($user->pokemon): ?>
			<?php echo e($user->pokemon->name); ?>

			<?php endif; ?>
			</td>
			<td>
				<?php if($user->id === $loginer->id): ?>
					<?php echo e(link_to_route('profiles.index',"edit",[$loginer->id])); ?>

				<?php endif; ?>
			</td>

			<td>
				<?php if($user->isAdmin): ?> 
					<?php echo e("Yes"); ?>

				<?php else: ?>
					<?php echo e("No"); ?>

				<?php endif; ?>	
			</td>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</table>


	    </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>