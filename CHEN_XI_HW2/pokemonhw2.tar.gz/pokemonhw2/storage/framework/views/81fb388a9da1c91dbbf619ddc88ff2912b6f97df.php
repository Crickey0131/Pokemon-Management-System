<!DOCTYPE html>
<html>
    <head>
	<title>Laravel</title>
    </head>
    <body>
	<div class="container">
	    <div class="content">
		<h2><?php echo e($pokemon_name->name); ?> has been in <?php echo e($pokemon_name->trainers->count()); ?> trainers</h2>
		<ul><?php $__currentLoopData = $pokemon_name->trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<li><a href=""><?php echo e($trainer->name); ?></a></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</ul>
	    </div>
	</div>
    </body>
</html>
