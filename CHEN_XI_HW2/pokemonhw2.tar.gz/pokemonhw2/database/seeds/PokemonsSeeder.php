<?php

use Illuminate\Database\Seeder;

class PokemonsSeeder extends Seeder
{

    public function run()
    {
	DB::table('pokemons')->delete();
	$pokemons = array(
	["id"=>1, "name"=>"BULBASAUR","created_at" => new DateTime, "updated_at"=> new DateTime],
	["id"=>2, "name"=>"CHARMANDER","created_at" => new DateTime, "updated_at"=> new DateTime],
	["id"=>3, "name"=>"SQUIRTLE","created_at" => new DateTime, "updated_at" => new DateTime]
	);
	DB::table('pokemons')->insert($pokemons);
    }
}
