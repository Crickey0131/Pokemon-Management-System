<?php

use Illuminate\Database\Seeder;

class TrainersSeeder extends Seeder
{

    public function run()
    {
	DB::table('trainers')->delete();
	$trainers = array(
	["id"=>1, "pokemon_id"=>1,"name"=>"Ash","hometown"=>"usc","isAdmin"=>false,"email"=>"ash@usc.edu","password"=>"888","created_at" => new DateTime, "updated_at"=> new DateTime]
	);
	DB::table('trainers')->insert($trainers);
    }
}
