<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTrainersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('trainers', function (Blueprint $table) {
            $table->increments('id');
	    $table->integer('pokemon_id')->unsigned()->default(0);
	    $table->foreign('pokemon_id')->references('id')->on('pokemons')->onDelete('cascade');
	    $table->string('name')->default('');
	    $table->string('hometown')->default('');
	    $table->string('email')->default('');
	    $table->string('password')->default('');
	    $table->boolean('isAdmin')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('trainers');
    }
}
